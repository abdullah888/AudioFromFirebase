//
//  mp3PlayerApp.swift
//  mp3Player
//
//  Created by abdullah on 14/03/1442 AH.
//

import SwiftUI
import Firebase


@main

struct FileApp: App {

    let data = OurData()

    init() {
        FirebaseApp.configure()
        data.loadAlbums()
    }

    var body: some Scene {
        WindowGroup {
            ContentView(data: data)
        }
    }
}

